<h1>Task 4</h1>
<p>Build a personal portfolio website that showcases your skills, projects, and accomplishments as a web developer. Design an attractive and visually appealing layout that captures visitors' attention. Include a home page with a captivating headline, professional photo, and summary of your skills. Provide an "About Me" section with a detailed background, education, and professional experience.</p><br>
<ul>
  <caption>Technologies & Tools</caption>
  <li>Html5 , Css3 , Javascript(ES6)</li>
  <li>Github , Vscode , Netlify</li>
</ul>

<a href = "https://portfoliobyhardik.netlify.app/">Live Demo</a>
